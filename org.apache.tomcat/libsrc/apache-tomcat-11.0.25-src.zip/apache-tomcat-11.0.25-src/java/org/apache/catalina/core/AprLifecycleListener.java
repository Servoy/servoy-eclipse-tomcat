/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.catalina.core;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;

import org.apache.catalina.Lifecycle;
import org.apache.catalina.LifecycleEvent;
import org.apache.catalina.LifecycleListener;
import org.apache.catalina.Server;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.jni.Library;
import org.apache.tomcat.jni.LibraryNotFoundError;
import org.apache.tomcat.jni.SSL;
import org.apache.tomcat.util.ExceptionUtils;
import org.apache.tomcat.util.res.StringManager;

/**
 * Implementation of <code>LifecycleListener</code> that will init and destroy APR.
 * <p>
 * This listener must only be nested within {@link Server} elements.
 * <p>
 * Only one instance of the APR/Native library may be loaded per JVM. Loading multiple instances will trigger a JVM
 * crash - typically when the Connectors are destroyed. This listener utilises reference counting to ensure that only
 * one instance of the APR/Native library is loaded at any one time.
 * <p>
 * If multiple listener configurations are found, only the first one initialised will be used.
 *
 * @since 4.1
 */
public class AprLifecycleListener implements LifecycleListener {

    private static final Log log = LogFactory.getLog(AprLifecycleListener.class);

    /**
     * Info messages during init() are cached until Lifecycle.BEFORE_INIT_EVENT so that, in normal (non-error) cases,
     * init() related log messages appear at the expected point in the lifecycle.
     */
    private static final List<String> initInfoLogMessages = new ArrayList<>(3);

    /**
     * The string manager for this package.
     */
    protected static final StringManager sm = StringManager.getManager(AprLifecycleListener.class);


    // ---------------------------------------------- Constants

    private static final int TCN_1_REQUIRED_MINOR = 3;
    private static final int TCN_1_REQUIRED_PATCH = 8;

    /** Required major version of Tomcat Native. */
    protected static final int TCN_REQUIRED_MAJOR = 2;
    /** Required minor version of Tomcat Native. */
    protected static final int TCN_REQUIRED_MINOR = 0;
    /** Required patch version of Tomcat Native. */
    protected static final int TCN_REQUIRED_PATCH = 15;
    /** Recommended major version of Tomcat Native. */
    protected static final int TCN_RECOMMENDED_MAJOR = 2;
    /** Recommended minor version of Tomcat Native. */
    protected static final int TCN_RECOMMENDED_MINOR = 0;
    /** Recommended patch version of Tomcat Native. */
    protected static final int TCN_RECOMMENDED_PV = 15;


    // ---------------------------------------------- Properties

    private static int tcnMajor = 0;
    private static int tcnMinor = 0;
    private static int tcnPatch = 0;
    private static int tcnVersion = 0;

    /** SSL engine configuration. */
    protected static String SSLEngine = "on"; // default on
    /** FIPS mode configuration. */
    protected static String FIPSMode = "off"; // default off, valid only when SSLEngine="on"
    /** SSL random seed source. */
    protected static String SSLRandomSeed = "builtin";
    /** Indicates whether SSL has been initialized. */
    protected static boolean sslInitialized = false;
    /** Indicates whether FIPS mode is currently active. */
    protected static boolean fipsModeActive = false;

    /**
     * The "FIPS mode" level that we use as the argument to OpenSSL method <code>FIPS_mode_set()</code> to enable FIPS
     * mode and that we expect as the return value of <code>FIPS_mode()</code> when FIPS mode is enabled.
     * <p>
     * In the future the OpenSSL library might grow support for different non-zero "FIPS" modes that specify different
     * allowed subsets of ciphers or whatever, but nowadays only "1" is the supported value.
     * </p>
     *
     * @see <a href="http://wiki.openssl.org/index.php/FIPS_mode_set%28%29">OpenSSL method FIPS_mode_set()</a>
     * @see <a href="http://wiki.openssl.org/index.php/FIPS_mode%28%29">OpenSSL method FIPS_mode()</a>
     */
    private static final int FIPS_ON = 1;

    private static final int FIPS_OFF = 0;

    // Guarded APRStatus.getStatusLock()
    private static int referenceCount = 0;
    private boolean instanceInitialized = false;


    /**
     * Checks APR availability, initializing if necessary.
     *
     * @return {@code true} if APR is available
     */
    public static boolean isAprAvailable() {
        // https://bz.apache.org/bugzilla/show_bug.cgi?id=48613
        if (org.apache.tomcat.jni.AprStatus.isInstanceCreated()) {
            Lock writeLock = org.apache.tomcat.jni.AprStatus.getStatusLock().writeLock();
            writeLock.lock();
            try {
                init();
            } finally {
                writeLock.unlock();
            }
        }
        return org.apache.tomcat.jni.AprStatus.isAprAvailable();
    }

    /**
     * Helper method to safely get a version string from APR/TCN.
     * Checks APR availability and handles exceptions.
     *
     * @param versionSupplier supplier that returns the version string
     * @return the version string, or null if APR is not available or an error occurs
     */
    private static String getVersionString(java.util.function.Supplier<String> versionSupplier) {
        if (!isAprAvailable()) {
            return null;
        }

        try {
            return versionSupplier.get();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Get the installed Tomcat Native version string, if available.
     *
     * @return the version string, or null if APR is not available
     */
    public static String getInstalledTcnVersion() {
        return getVersionString(org.apache.tomcat.jni.Library::versionString);
    }

    /**
     * Get the installed APR version string, if available.
     *
     * @return the APR version string, or null if APR is not available
     */
    public static String getInstalledAprVersion() {
        return getVersionString(org.apache.tomcat.jni.Library::aprVersionString);
    }

    /**
     * Get the installed OpenSSL version string (via APR), if available.
     *
     * @return the OpenSSL version string, or null if not available
     */
    public static String getInstalledOpenSslVersion() {
        return getVersionString(org.apache.tomcat.jni.SSL::versionString);
    }

    /**
     * Helper method to convert version components to a comparable integer.
     *
     * @param major major version number
     * @param minor minor version number
     * @param patch patch version number
     *
     * @return comparable version integer
     */
    private static int versionToInt(int major, int minor, int patch) {
        return major * 1000 + minor * 100 + patch;
    }

    /**
     * Get a warning message if the installed Tomcat Native version is older than recommended.
     * This performs the same version check used during Tomcat startup.
     *
     * @return a warning message if the installed version is outdated, or null if the version
     *         is acceptable or APR is not available
     */
    public static String getTcnVersionWarning() {
        if (!isAprAvailable()) {
            return null;
        }

        try {
            int installedVersion = versionToInt(
                    org.apache.tomcat.jni.Library.TCN_MAJOR_VERSION,
                    org.apache.tomcat.jni.Library.TCN_MINOR_VERSION,
                    org.apache.tomcat.jni.Library.TCN_PATCH_VERSION);
            int recommendedVersion = versionToInt(
                    TCN_RECOMMENDED_MAJOR,
                    TCN_RECOMMENDED_MINOR,
                    TCN_RECOMMENDED_PV);
            if (installedVersion < recommendedVersion) {
                return "WARNING: Tomcat recommends a minimum version of " +
                        TCN_RECOMMENDED_MAJOR + "." + TCN_RECOMMENDED_MINOR + "." + TCN_RECOMMENDED_PV;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    /** Constructs a new AprLifecycleListener. */
    public AprLifecycleListener() {
        org.apache.tomcat.jni.AprStatus.setInstanceCreated(true);
    }

    // ---------------------------------------------- LifecycleListener Methods

    /**
     * Primary entry point for startup and shutdown events.
     *
     * @param event The event that has occurred
     */
    @Override
    public void lifecycleEvent(LifecycleEvent event) {

        if (Lifecycle.BEFORE_INIT_EVENT.equals(event.getType())) {
            Lock writeLock = org.apache.tomcat.jni.AprStatus.getStatusLock().writeLock();
            writeLock.lock();
            try {
                instanceInitialized = true;
                if (!(event.getLifecycle() instanceof Server)) {
                    log.warn(sm.getString("listener.notServer", event.getLifecycle().getClass().getSimpleName()));
                }
                if (referenceCount++ != 0) {
                    // Already loaded (note test is performed before reference count is incremented)
                    return;
                }
                init();
                for (String msg : initInfoLogMessages) {
                    log.info(msg);
                }
                initInfoLogMessages.clear();
                if (org.apache.tomcat.jni.AprStatus.isAprAvailable()) {
                    try {
                        initializeSSL();
                    } catch (Throwable t) {
                        Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
                        ExceptionUtils.handleThrowable(throwable);
                        log.error(sm.getString("aprListener.sslInit"), throwable);
                    }
                }
                // Failure to initialize FIPS mode is fatal
                if (!(null == FIPSMode || "off".equalsIgnoreCase(FIPSMode)) && !isFIPSModeActive()) {
                    Error e = new Error(sm.getString("aprListener.initializeFIPSFailed"));
                    // Log here, because thrown error might be not logged
                    log.fatal(e.getMessage(), e);
                    throw e;
                }
            } finally {
                writeLock.unlock();
            }
        } else if (Lifecycle.AFTER_DESTROY_EVENT.equals(event.getType())) {
            Lock writeLock = org.apache.tomcat.jni.AprStatus.getStatusLock().writeLock();
            writeLock.lock();
            try {
                // Instance may get destroyed without ever being initialized
                if (instanceInitialized) {
                    referenceCount--;
                }
                if (referenceCount != 0) {
                    // Still being used
                    return;
                }
                if (!org.apache.tomcat.jni.AprStatus.isAprAvailable()) {
                    return;
                }
                try {
                    terminateAPR();
                } catch (Throwable t) {
                    Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
                    ExceptionUtils.handleThrowable(throwable);
                    log.warn(sm.getString("aprListener.aprDestroy"), throwable);
                }
            } finally {
                writeLock.unlock();
            }
        }

    }

    private static void terminateAPR() {
        org.apache.tomcat.jni.AprStatus.setAprInitialized(false);
        org.apache.tomcat.jni.AprStatus.setAprAvailable(false);
        fipsModeActive = false;
        sslInitialized = false; // terminate() will clean the pool
        // There could be unreferenced SSL_CTX still waiting for GC
        System.gc();
        Library.terminate();
    }

    private static void init() {
        if (org.apache.tomcat.jni.AprStatus.isAprInitialized()) {
            return;
        }
        org.apache.tomcat.jni.AprStatus.setAprInitialized(true);

        try {
            Library.initialize(null);
            tcnMajor = Library.TCN_MAJOR_VERSION;
            tcnMinor = Library.TCN_MINOR_VERSION;
            tcnPatch = Library.TCN_PATCH_VERSION;
            tcnVersion = tcnMajor * 1000 + tcnMinor * 100 + tcnPatch;
        } catch (LibraryNotFoundError lnfe) {
            // Library not on path
            if (log.isDebugEnabled()) {
                log.debug(sm.getString("aprListener.aprInitDebug", lnfe.getLibraryNames(),
                        System.getProperty("java.library.path"), lnfe.getMessage()), lnfe);
            }
            initInfoLogMessages.add(sm.getString("aprListener.aprInit", System.getProperty("java.library.path")));
            return;
        } catch (Throwable t) {
            // Library present but failed to load
            Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
            ExceptionUtils.handleThrowable(throwable);
            log.warn(sm.getString("aprListener.aprInitError", throwable.getMessage()), throwable);
            return;
        }
        if (tcnMajor > 1 && "off".equalsIgnoreCase(SSLEngine)) {
            log.error(sm.getString("aprListener.sslRequired", SSLEngine, Library.versionString()));
            try {
                // Tomcat Native 2.x onwards requires SSL
                terminateAPR();
            } catch (Throwable t) {
                Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
                ExceptionUtils.handleThrowable(throwable);
            }
            return;
        }

        /*
         * With parallel development of 1.x and 2.x there are now minimum and recommended versions for both branches.
         *
         * The minimum required version is increased when the Tomcat Native API is changed (typically extended) to
         * include functionality that Tomcat expects to always be present.
         *
         * The minimum recommended version is increased when there is a change in Tomcat Native that while not required
         * is recommended (such as bug fixes).
         */
        int rqver;
        int rcver;
        if (tcnMajor == 1) {
            rqver = 1000 + TCN_1_REQUIRED_MINOR * 100 + TCN_1_REQUIRED_PATCH;
            rcver = TCN_RECOMMENDED_MAJOR * 1000 + TCN_RECOMMENDED_MINOR * 100 + TCN_RECOMMENDED_PV;
        } else {
            rqver = TCN_REQUIRED_MAJOR * 1000 + TCN_REQUIRED_MINOR * 100 + TCN_REQUIRED_PATCH;
            rcver = TCN_RECOMMENDED_MAJOR * 1000 + TCN_RECOMMENDED_MINOR * 100 + TCN_RECOMMENDED_PV;
        }

        if (tcnVersion < rqver) {
            if (tcnMajor == 1) {
                log.error(sm.getString("aprListener.tcnInvalid.1", Library.versionString(),
                        "1." + TCN_1_REQUIRED_MINOR + "." + TCN_1_REQUIRED_PATCH));
            } else {
                log.error(sm.getString("aprListener.tcnInvalid", Library.versionString(),
                        TCN_REQUIRED_MAJOR + "." + TCN_REQUIRED_MINOR + "." + TCN_REQUIRED_PATCH));
            }
            try {
                // Terminate the APR in case the version
                // is below required.
                terminateAPR();
            } catch (Throwable t) {
                Throwable throwable = ExceptionUtils.unwrapInvocationTargetException(t);
                ExceptionUtils.handleThrowable(throwable);
            }
            return;
        }
        if (tcnVersion < rcver) {
            initInfoLogMessages.add(sm.getString("aprListener.tcnVersion", Library.versionString(),
                    TCN_RECOMMENDED_MAJOR + "." + TCN_RECOMMENDED_MINOR + "." + TCN_RECOMMENDED_PV));
        }

        initInfoLogMessages
                .add(sm.getString("aprListener.tcnValid", Library.versionString(), Library.aprVersionString()));

        org.apache.tomcat.jni.AprStatus.setAprAvailable(true);
    }

    private static void initializeSSL() throws Exception {

        if ("off".equalsIgnoreCase(SSLEngine)) {
            return;
        }
        if (sslInitialized) {
            // Only once per VM
            return;
        }

        sslInitialized = true;

        String methodName = "randSet";
        Class<?>[] paramTypes = new Class[1];
        paramTypes[0] = String.class;
        Object[] paramValues = new Object[1];
        paramValues[0] = SSLRandomSeed;
        Class<?> clazz = Class.forName("org.apache.tomcat.jni.SSL");
        Method method = clazz.getMethod(methodName, paramTypes);
        method.invoke(null, paramValues);


        methodName = "initialize";
        paramValues[0] = "on".equalsIgnoreCase(SSLEngine) ? null : SSLEngine;
        method = clazz.getMethod(methodName, paramTypes);
        method.invoke(null, paramValues);

        org.apache.tomcat.jni.AprStatus.setOpenSSLVersion(SSL.version());
        // OpenSSL 3 onwards uses providers
        boolean usingProviders = tcnMajor > 1 || (tcnVersion > 1233 && (SSL.version() & 0xF0000000L) > 0x20000000);

        // Tomcat Native 1.x built with OpenSSL 1.x without explicitly enabling
        // FIPS and Tomcat Native < 1.2.34 built with OpenSSL 3.x will fail if
        // any calls are made to SSL.fipsModeGet or SSL.fipsModeSet
        if (usingProviders || !(null == FIPSMode || "off".equalsIgnoreCase(FIPSMode))) {
            fipsModeActive = false;
            final boolean enterFipsMode;
            int fipsModeState = SSL.fipsModeGet();

            if (log.isDebugEnabled()) {
                log.debug(sm.getString("aprListener.currentFIPSMode", Integer.valueOf(fipsModeState)));
            }

            if (null == FIPSMode || "off".equalsIgnoreCase(FIPSMode)) {
                if (fipsModeState == FIPS_ON) {
                    fipsModeActive = true;
                }
                enterFipsMode = false;
            } else if ("on".equalsIgnoreCase(FIPSMode)) {
                if (fipsModeState == FIPS_ON) {
                    if (!usingProviders) {
                        log.info(sm.getString("aprListener.skipFIPSInitialization"));
                    }
                    fipsModeActive = true;
                    enterFipsMode = false;
                } else {
                    if (usingProviders) {
                        throw new IllegalStateException(sm.getString("aprListener.FIPSProviderNotDefault", FIPSMode));
                    } else {
                        enterFipsMode = true;
                    }
                }
            } else if ("require".equalsIgnoreCase(FIPSMode)) {
                if (fipsModeState == FIPS_ON) {
                    fipsModeActive = true;
                    enterFipsMode = false;
                } else {
                    if (usingProviders) {
                        throw new IllegalStateException(sm.getString("aprListener.FIPSProviderNotDefault", FIPSMode));
                    } else {
                        throw new IllegalStateException(sm.getString("aprListener.requireNotInFIPSMode"));
                    }
                }
            } else if ("enter".equalsIgnoreCase(FIPSMode)) {
                if (fipsModeState == FIPS_OFF) {
                    if (usingProviders) {
                        throw new IllegalStateException(sm.getString("aprListener.FIPSProviderNotDefault", FIPSMode));
                    } else {
                        enterFipsMode = true;
                    }
                } else {
                    if (usingProviders) {
                        fipsModeActive = true;
                        enterFipsMode = false;
                    } else {
                        throw new IllegalStateException(
                                sm.getString("aprListener.enterAlreadyInFIPSMode", Integer.valueOf(fipsModeState)));
                    }
                }
            } else {
                throw new IllegalArgumentException(sm.getString("aprListener.wrongFIPSMode", FIPSMode));
            }

            if (enterFipsMode) {
                log.info(sm.getString("aprListener.initializingFIPS"));

                fipsModeState = SSL.fipsModeSet(FIPS_ON);
                if (fipsModeState != FIPS_ON) {
                    // This case should be handled by the native method,
                    // but we'll make absolutely sure, here.
                    String message = sm.getString("aprListener.initializeFIPSFailed");
                    log.error(message);
                    throw new IllegalStateException(message);
                }

                fipsModeActive = true;
                log.info(sm.getString("aprListener.initializeFIPSSuccess"));
            }

            if (usingProviders && fipsModeActive) {
                log.info(sm.getString("aprListener.usingFIPSProvider"));
            }
        }

        log.info(sm.getString("aprListener.initializedOpenSSL", SSL.versionString()));
    }

    /**
     * Returns the SSL engine configuration.
     *
     * @return the SSL engine configuration
     */
    public String getSSLEngine() {
        return SSLEngine;
    }

    /**
     * Sets the SSL engine configuration.
     *
     * @param SSLEngine the SSL engine configuration
     */
    public void setSSLEngine(String SSLEngine) {
        if (!SSLEngine.equals(AprLifecycleListener.SSLEngine)) {
            // Ensure that the SSLEngine is consistent with that used for SSL init
            if (sslInitialized) {
                throw new IllegalStateException(sm.getString("aprListener.tooLateForSSLEngine"));
            }

            AprLifecycleListener.SSLEngine = SSLEngine;
        }
    }

    /**
     * Returns the SSL random seed source.
     *
     * @return the SSL random seed source
     */
    public String getSSLRandomSeed() {
        return SSLRandomSeed;
    }

    /**
     * Sets the SSL random seed source.
     *
     * @param SSLRandomSeed the SSL random seed source
     */
    public void setSSLRandomSeed(String SSLRandomSeed) {
        if (!SSLRandomSeed.equals(AprLifecycleListener.SSLRandomSeed)) {
            // Ensure that the random seed is consistent with that used for SSL init
            if (sslInitialized) {
                throw new IllegalStateException(sm.getString("aprListener.tooLateForSSLRandomSeed"));
            }

            AprLifecycleListener.SSLRandomSeed = SSLRandomSeed;
        }
    }

    /**
     * Returns the FIPS mode configuration.
     *
     * @return the FIPS mode configuration
     */
    public String getFIPSMode() {
        return FIPSMode;
    }

    /**
     * Sets the FIPS mode configuration.
     *
     * @param FIPSMode the FIPS mode configuration
     */
    public void setFIPSMode(String FIPSMode) {
        if (!FIPSMode.equals(AprLifecycleListener.FIPSMode)) {
            // Ensure that the FIPS mode is consistent with that used for SSL init
            if (sslInitialized) {
                throw new IllegalStateException(sm.getString("aprListener.tooLateForFIPSMode"));
            }

            AprLifecycleListener.FIPSMode = FIPSMode;
        }
    }

    /**
     * Returns whether FIPS mode is currently active.
     *
     * @return {@code true} if FIPS mode is active
     */
    public boolean isFIPSModeActive() {
        return fipsModeActive;
    }

    /**
     * Configures whether to use OpenSSL.
     *
     * @param useOpenSSL {@code true} to use OpenSSL
     */
    public void setUseOpenSSL(boolean useOpenSSL) {
        if (useOpenSSL != org.apache.tomcat.jni.AprStatus.getUseOpenSSL()) {
            org.apache.tomcat.jni.AprStatus.setUseOpenSSL(useOpenSSL);
        }
    }

    /**
     * Returns whether OpenSSL is in use.
     *
     * @return {@code true} if OpenSSL is in use
     */
    public static boolean getUseOpenSSL() {
        return org.apache.tomcat.jni.AprStatus.getUseOpenSSL();
    }

    /**
     * Returns whether an APR instance has been created.
     *
     * @return {@code true} if an APR instance has been created
     */
    public static boolean isInstanceCreated() {
        return org.apache.tomcat.jni.AprStatus.isInstanceCreated();
    }

}
