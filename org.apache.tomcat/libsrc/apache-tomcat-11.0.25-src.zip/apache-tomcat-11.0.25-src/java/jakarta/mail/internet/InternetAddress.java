/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jakarta.mail.internet;

/**
 * Represents an Internet email address as defined by RFC 822.
 * An Internet address consists of an optional personal name and
 * an address string in the form of local-part@domain.
 * NOTE: This is a stub API, Apache Tomcat does not provide any implementation for this API.
 */
public class InternetAddress {
    /**
     * Constructs an InternetAddress from the specified address string.
     * The address string may optionally include a personal name portion.
     *
     * @param from the email address string to parse
     */
    public InternetAddress(String from) {
        // Dummy implementation
    }
}
