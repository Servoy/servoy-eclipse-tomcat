/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jakarta.servlet.http;

import jakarta.servlet.annotation.WebServlet;

/**
 * Represents how the request from which this object was obtained was mapped to the associated servlet.
 *
 * @since Servlet 4.0
 */
public interface HttpServletMapping {

    /**
     * Returns the value that was matched when mapping the request to the servlet.
     *
     * @return The value that was matched or the empty String if not known.
     */
    String getMatchValue();

    /**
     * Returns the URL pattern that matched this request.
     *
     * @return The {@code url-pattern} that matched this request or the empty String if not known.
     */
    String getPattern();

    /**
     * Returns the name of the servlet to which the request was mapped.
     *
     * @return The name of the servlet (as specified in web.xml, {@link WebServlet#name()},
     *             {@link jakarta.servlet.ServletContext#addServlet(String, Class)} or one of the other
     *             <code>addServlet()</code> methods) that the request was mapped to.
     */
    String getServletName();

    /**
     * Returns the type of match used to map the request to the servlet.
     *
     * @return The type of match ({@code null} if not known)
     */
    MappingMatch getMappingMatch();
}
