/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jakarta.el;

import java.util.Objects;

/**
 * ELResolver that resolves bean names to bean instances using a {@link BeanNameResolver}. This resolver handles
 * expressions where the base is {@code null} and the property is a {@link String} representing a bean name.
 *
 * @since EL 3.0
 */
public class BeanNameELResolver extends ELResolver {

    private final BeanNameResolver beanNameResolver;

    /**
     * Constructs a BeanNameELResolver with the specified BeanNameResolver.
     *
     * @param beanNameResolver the resolver used to look up beans by name
     */
    public BeanNameELResolver(BeanNameResolver beanNameResolver) {
        this.beanNameResolver = beanNameResolver;
    }

    @Override
    public Object getValue(ELContext context, Object base, Object property) {
        Objects.requireNonNull(context);
        if (base != null || !(property instanceof String beanName)) {
            return null;
        }

        if (beanNameResolver.isNameResolved(beanName)) {
            try {
                Object result = beanNameResolver.getBean(beanName);
                context.setPropertyResolved(null, property);
                return result;
            } catch (Throwable t) {
                Util.handleThrowable(t);
                throw new ELException(t);
            }
        }

        return null;
    }

    @Override
    public void setValue(ELContext context, Object base, Object property, Object value) {
        Objects.requireNonNull(context);
        if (base != null || !(property instanceof String beanName)) {
            return;
        }

        boolean isResolved = context.isPropertyResolved();

        boolean isReadOnly;
        try {
            isReadOnly = isReadOnly(context, null, property);
        } catch (Throwable t) {
            Util.handleThrowable(t);
            throw new ELException(t);
        } finally {
            context.setPropertyResolved(isResolved);
        }

        if (isReadOnly) {
            throw new PropertyNotWritableException(Util.message(context, "beanNameELResolver.beanReadOnly", beanName));
        }

        if (beanNameResolver.isNameResolved(beanName) || beanNameResolver.canCreateBean(beanName)) {
            try {
                beanNameResolver.setBeanValue(beanName, value);
                context.setPropertyResolved(null, property);
            } catch (Throwable t) {
                Util.handleThrowable(t);
                throw new ELException(t);
            }
        }
    }

    @Override
    public Class<?> getType(ELContext context, Object base, Object property) {
        Objects.requireNonNull(context);
        if (base != null || !(property instanceof String beanName)) {
            return null;
        }

        try {
            if (beanNameResolver.isNameResolved(beanName)) {
                Class<?> result = beanNameResolver.getBean(beanName).getClass();
                context.setPropertyResolved(null, property);

                /*
                 * No resolver level isReadOnly property for this resolver
                 */
                if (beanNameResolver.isReadOnly((String) property)) {
                    return null;
                }

                return result;
            }
        } catch (Throwable t) {
            Util.handleThrowable(t);
            throw new ELException(t);
        }

        return null;
    }

    @Override
    public boolean isReadOnly(ELContext context, Object base, Object property) {
        Objects.requireNonNull(context);
        if (base != null || !(property instanceof String beanName)) {
            // Return value undefined
            return false;
        }

        if (beanNameResolver.isNameResolved(beanName)) {
            boolean result;
            try {
                result = beanNameResolver.isReadOnly(beanName);
            } catch (Throwable t) {
                Util.handleThrowable(t);
                throw new ELException(t);
            }
            context.setPropertyResolved(null, property);
            return result;
        }

        // Return value undefined
        return false;
    }

    @Override
    public Class<?> getCommonPropertyType(ELContext context, Object base) {
        return String.class;
    }
}
